Maths Revision Tool, Version 1
Curtis Thompson
30/04/2016

-----------------------------------------------------------------------
NOTES:
-----------------------------------------------------------------------
 - Full information on how to use the program can be found in the user manual
 - To return to the menu at any point you must click the X in the top right corner. If you click this on the menu you will logout and return to the login screen. If you click this on the login screen you will exit the program.
 - Maths codes for answering questions can be directly typed into the answer box, or alternatively with the 'Add' button on the on the maths code page if the revision session page is also open at the same time

-----------------------------------------------------------------------
INITIAL LOGIN:
-----------------------------------------------------------------------
Load the program
Click on 'Create Account' from the login screen
Type in new username and password
Login with new account

-----------------------------------------------------------------------
TO START A REVISION SESSION:
-----------------------------------------------------------------------
Click on 'Revise' on the main menu
Select a topic from the drop down list, enter a number of questions and click 'Add Topic'
Repeat to add whichever topics you wish to revise
Click 'Generate Questions' when ready to start session

-----------------------------------------------------------------------
ANSWERING AND SAVING QUESTIONS IN REVISION SESSION:
-----------------------------------------------------------------------
In session, click 'Next Question' and 'Previous Question' to go between questions
Click 'Save Question' to save a question (to be viewed later)
Enter answers in the answer box, where it says 'Enter Answer Here...'
Click 'Mark Answers' once finished
Continue to the feedback page

-----------------------------------------------------------------------
TO VIEW MATHS CODES FOR ANSWERING QUESTIONS:
-----------------------------------------------------------------------
From the menu, click 'Program Info'
Then click 'View Maths Codes'

From the revision session page, click the question mark next to the answer box

-----------------------------------------------------------------------
TO VIEW PREVIOUSLY SAVED QUESTIONS:
-----------------------------------------------------------------------
From the menu, click 'Saved Questions'
Click 'Next Question' and 'Previous Question' to go between saved questions
Questions will only show if they were saved from your account

-----------------------------------------------------------------------
TO VIEW PREVIOUS FEEDBACK:
-----------------------------------------------------------------------
From the menu, click 'Feedback'
Click 'Next' and 'Back' to go between feedback
Feedback will only show if saved from your account